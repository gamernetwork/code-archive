<?php

return array(
	'English'    => 'en',
	'Dutch'      => 'nl',
	'French'     => 'fr',
	'German'     => 'de',
	'Italian'    => 'it',
	'Portuguese' => 'pt',
	'Russian'    => 'ru',
	'Spanish'    => 'es',
	'Turkish'    => 'tr'
);
