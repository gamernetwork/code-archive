simple-301-redirects
====================
**Notice: This entire repository should be considered experimental. The stable version of this plugin should always be [downloaded from the WordPress Plugin Directory](https://wordpress.org/plugins/simple-301-redirects/ "Download the release version of Simple 301 Redirects").**

Simple 301 Redirects is a popular URL Redirection plugin for WordPress
