edButtons[edButtons.length] = new edButton(
	'pullquote'
	,'pullquote'
	,'[pullquote]'
	,'[/pullquote]'
	,''
	);

/*
Source: http://www.tamba2.org.uk/wordpress/quicktags/

edButtons[edButtons.length] = new edButton(
'sup' :The name of the button
,'sup' :What you see on the button
,'<sup>' : the opening tag
,'</sup>' : the closing tag
,'' : blank - no key set
); 

*/