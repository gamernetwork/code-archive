<?php
/*
Plugin Name: DualFeeds
Plugin URI: http://www.scratch99.com/wordpress-plugin-dualfeeds/
Description: Allows you to offer your readers both a full post feed and a summary feed. Works for all post feeds (main site feed, category feeds, etc). Comment feeds are unaffected.
Version: 1.11
Date: 28th December 2007
Author: Stephen Cronin
Author URI: http://www.scratch99.com/
   
   Copyright 2007  Stephen Cronin  (email : sjc@scratch99.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

****************** NOTE TO PEOPLE READING THIS ****************** 
I have tried to keep the code AS SIMPLE AS POSSIBLE (no ternary operators here). 
Why? To make this as easy to follow as possible. There are many people new to 
php who are trying to write WordPress plugins. If you're one, feel free to use this 
plugin as an example, but be aware that there may more elegent ways to do this. 
You can learn about ternary operators later!
*************************************************************
*/

// ****** GLOBAL VARIABLES AND CONSTANTS ******
$dualfeeds_options = get_option('dualfeeds_options');
define('DF_VERSION', '1.11');
define('DF_DATE', '28th December 2007');
define('DF_PATH', get_settings('siteurl') . '/wp-content/plugins/' . dirname(plugin_basename(__FILE__)));
// *******************************************

// ****** SETUP ACTIONS AND FILTERS ******
// setup options db on activation of plugin (works even if user changes folder name). 
add_action('activate_' . dirname(plugin_basename(__FILE__)) . '/' . basename(__FILE__), 'create_dualfeeds_options');
add_action('admin_menu', 'dualfeeds_admin');
add_filter('the_content', 'dualfeeds',-1);		// use -1 so it is called first before other formatting is applied to it
add_action('wp_head', 'dualfeeds_head');
add_action('plugins_loaded', 'dualfeeds_widget_init');
add_action('template_redirect', 'df_feedburner_redirect',-1);  // use -1 so it beats FeedSmith
add_action('init','df_check_url', -1); // use -1 so it beats FeedSmith
// **************************************

// ****** FUNCTION TO CREATE OPTIONS AND DEFAULTS ON ACTIVATION ******
function create_dualfeeds_options() {
	// get current options, assign defaults if not already set, update the options db
	global $dualfeeds_options;
	if (!isset($dualfeeds_options['df_switch'])){ $dualfeeds_options['df_switch'] = 'false';}
	if (!isset($dualfeeds_options['df_summarylength'])){ $dualfeeds_options['df_summarylength'] = '500';}
	if (!isset($dualfeeds_options['df_sidebarimage'])){ $dualfeeds_options['df_sidebarimage'] = 'orangemix.png';}
	if (!isset($dualfeeds_options['df_sidebarshowtext'])){ $dualfeeds_options['df_sidebarshowtext'] == 'false';}
	if (!isset($dualfeeds_options['df_ifyoulikedthis'])){ $dualfeeds_options['df_ifyoulikedthis'] = 'Subscribe To Site:';}
	if (!isset($dualfeeds_options['df_ifyoulikedthissize'])){ $dualfeeds_options['df_ifyoulikedthissize'] = 'feed-icon16.gif';}
	if (!isset($dualfeeds_options['df_showposts'])){ $dualfeeds_options['df_showposts'] = 'false';}
	if (!isset($dualfeeds_options['df_showpages'])){ $dualfeeds_options['df_showpages'] = 'false';}
	if (!isset($dualfeeds_options['df_showhome'])){ $dualfeeds_options['df_showhome'] = 'false';}
	if (!isset($dualfeeds_options['df_showcategory'])){ $dualfeeds_options['df_showcategory'] = 'false';}
	if (!isset($dualfeeds_options['df_showdate'])){ $dualfeeds_options['df_showdate'] = 'false';}
	if (!isset($dualfeeds_options['df_showtag'])){ $dualfeeds_options['df_showtag'] = 'false';}
	if (!isset($dualfeeds_options['df_topborder'])){ $dualfeeds_options['df_topborder'] = 'false';}
	if (!isset($dualfeeds_options['df_bottomborder'])){ $dualfeeds_options['df_bottomborder'] = 'false';}
	if (!isset($dualfeeds_options['df_autodiscovery1'])){ $dualfeeds_options['df_autodiscovery1'] = 'false';}
	if (!isset($dualfeeds_options['df_autodiscovery2'])){ $dualfeeds_options['df_autodiscovery2'] = 'true';}
	if (!isset($dualfeeds_options['df_autodiscoveryC'])){ $dualfeeds_options['df_autodiscoveryC'] = 'true';}
	if (!isset($dualfeeds_options['df_feedburnerURL1'])){ $dualfeeds_options['df_feedburnerURL1'] = '';}
	if (!isset($dualfeeds_options['df_feedburnerURL2'])){ $dualfeeds_options['df_feedburnerURL2'] = '';}
	if (!isset($dualfeeds_options['df_feedburnerURLcomments'])){ $dualfeeds_options['df_feedburnerURLcomments'] = '';}
	update_option('dualfeeds_options', $dualfeeds_options);
}
// ******************************************************************

// ****** MAIN FUNCTION TO MANIPULATE FEED FORMATS ******
function dualfeeds($content) {
	// declare globals so we have access to them
	global $post, $dualfeeds_options;

	// only do anything if what we have is a feed. 
	if (is_feed()) {
	
		// get full post content, get location of more tag for later use, strip the more tag
		$content = $post->post_content;
		$morepos = strpos(strtolower($content),"<!--more-->");
		$content = str_replace("<!--more-->","", $post->post_content);

		// If we are dealing with extra feed or if default switched, do something
		// Otherwise do nothing and full post will be displayed
		if ( (strpos($_SERVER['REQUEST_URI'],'dualfeed=2') > 0 && $dualfeeds_options['df_switch']!='true') ||
		(strpos($_SERVER['REQUEST_URI'],'dualfeed=2') == 0 && $dualfeeds_options['df_switch']=='true') ) {

			// use excerpt if it exists
			if (!empty($post->post_excerpt)){
				$content = get_the_excerpt();
			} 
			// if no excerpt, cut post where more tag was, if it existed, but not if it was at beginning (ie $morepos >= 50).
			else if ($morepos >= 50) {
				$content = substr($content,0,$morepos);
			}
			// else chop full post at the end of the last word before the user parameter length
			else {
				$content = substr($content,0,$dualfeeds_options['df_summarylength']);
				$lastwordpos = strrpos($content," ");
				$content = substr($content,0,$lastwordpos);
			}
			$content = $content . ' ... [<a href="' . get_permalink() . '">visit site to read more</a>]';
		}

		// Make sure that the content of password protected post are not shown. 
		// WordPress normally shows this message anyway, but apparantly some people have a bug.
		if (!empty($post->post_password)){
			$content = 'There is no excerpt because this is a protected post. ... [<a href="' . get_permalink() . '">visit the site and login to read this</a>]';
		}
	}
	
	// if it's not a feed, then add feed links to the bottom of the post (depending on parameters)
	if (! is_feed()){
		
		// hack to cater for tags in 2.3+ only.
		$dualfeeds_showtag=false;
		if (function_exists('is_tag')) {
			if ($dualfeeds_options['df_showtag']=='true' && is_tag()) {
				$dualfeeds_showtag=true;
			}
		}	

		// rest of the logic
		if (($dualfeeds_options['df_showposts']=='true' && is_single() && !(get_post_meta($post->ID, 'pageextras',true)=="no")) ||
		($dualfeeds_options['df_showpages']=='true' && is_page() && !(get_post_meta($post->ID, 'pageextras',true)=="no")) ||
		($dualfeeds_options['df_showhome']=='true' && is_home()) ||
		($dualfeeds_options['df_showcategory']=='true' && is_category()) ||
		($dualfeeds_options['df_showdate']=='true' && is_date()) ||
		($dualfeeds_showtag==true)) {
			$value = $dualfeeds_options['df_ifyoulikedthissize'];
			$content = $content . '<div style="margin-top:16px;'; 
			if ($dualfeeds_options['df_topborder'] == 'true') {$content = $content .  ' border-top:solid; border-top-width:1px; border-color:#CCCCCC; padding-top:6px;';}
			if ($dualfeeds_options['df_bottomborder'] == 'true') {$content = $content . ' border-bottom:solid; border-bottom-width:1px; border-color:#CCCCCC; padding-bottom:10px;';}
			$content = $content . '"> <strong>' . $dualfeeds_options['df_ifyoulikedthis'] . '</strong>';
			$content = $content . '<div style="margin-left:12px; padding:0px"><a href="' . df_getfeedURL("fullpost") . '"><img src="'. DF_PATH . '/images/' . $value . '" border="0" style="border:0; margin:0; padding:0; vertical-align:middle" alt="Full Post Feed" /></a> <a href="' . df_getfeedURL("fullpost") . '">Full Post Feed</a> | ';
			$content = $content . '<a href="' . df_getfeedURL('summary') . '"><img src="'. DF_PATH . '/images/' . $value . '" border="0" style="border:0; margin:0; padding:0; vertical-align:middle" alt="Summary Feed" /></a> <a href="' . df_getfeedURL("summary") . '">Summary Feed</a> | ';
			$content = $content . '<a href="' . get_bloginfo('comments_rss2_url') . '"><img src="'. DF_PATH . '/images/' . $value . '" border="0" style="border:0; margin:0; padding:0; vertical-align:middle" alt="Comments Feed" /></a> <a href="' . get_bloginfo('comments_rss2_url') . '">Comments Feed</a>';
			$content = $content . '</div></div>';
		}
	}
	
	return $content;
}
// *****************************************************

// ****** FUNCTION TO ADD FEED AUTO-DISCOVERY TO HEAD SECTION ******
function dualfeeds_head(){
	global $dualfeeds_options;
	echo "<!-- Start of DualFeeds (" . DF_VERSION . ") plugin additions -->\n";
	if ($dualfeeds_options['df_autodiscovery1']=='true'){
		echo '<link rel="alternate" type="application/rss+xml" title="' . get_bloginfo('name') . ' - ' .df_getdescription('first') . '" href="' . get_bloginfo('rss2_url') . '" />'."\n";
	}
	if ($dualfeeds_options['df_autodiscovery2']=='true'){
		echo '<link rel="alternate" type="application/rss+xml" title="' . get_bloginfo('name') . ' - ' . df_getdescription('dualfeed=2') . '" href="' . df_addURLparam('dualfeed=2') . '" />'."\n";
	}
	if ($dualfeeds_options['df_autodiscoveryC']=='true'){
		echo '<link rel="alternate" type="application/rss+xml" title="' . get_bloginfo('name') . ' -  Comments Feed" href="' . get_bloginfo('comments_rss2_url') . '" />'."\n";
	}
	echo "<!-- End of DualFeeds plugin additions -->\n";
}
// *****************************************************************

// ****** FUNCTION TO INITIALISE WIDGET ******
function dualfeeds_widget_init() {
	if (function_exists('register_sidebar_widget') && function_exists('register_widget_control')) {
		register_sidebar_widget('DualFeeds', 'dualfeeds_widget');
	}
}
// *****************************************

// ****** FUNCTION TO CREATE WIDGET ******
function dualfeeds_widget($args) {
	extract($args);
	echo $before_widget;
	echo $before_title . $after_title;
	dualfeeds_sidebar();
	echo $after_widget;
}
// ***************************************

// ****** FUNCTION TO ECHO THE SIDEBAR - CALLED BY WIDGET, CAN ALSO BE CALLED DIRECTLY ******
function dualfeeds_sidebar() {
	global $dualfeeds_options;
	if ($dualfeeds_options['df_sidebarshowtext'] != 'true') {
		echo '<img src="' . DF_PATH . '/images/' . $dualfeeds_options['df_sidebarimage'] . '" border="0" style="border:0; margin:0; padding:0" alt="DualFeeds" usemap="#df_sidebar" />' . "\n";
		echo '<map name="df_sidebar" id="df_sidebar">' . "\n";
		echo '<area shape="rect" coords="80,27,176,39" href="' . df_getfeedURL('fullpost') . '" alt="Subscribe To Full Post Feed" />' . "\n";
		echo '<area shape="rect" coords="80,42,176,54" href="' . df_getfeedURL('summary') . '" alt="Subscribe To Summary Feed" />' . "\n";
		echo '<area shape="rect" coords="80,57,176,69" href="' . get_bloginfo('comments_rss2_url') . '" alt="Subscribe To Comments Feed" />' . "\n";
		echo "</map>\n";
	}
	else {
		echo '<img src="' . DF_PATH . '/images/subscribe.png" alt="feed icon" /><br />'."\n";
		echo '<ul><li><a href="' . df_getfeedURL('fullpost') . '">Full Post Feed</a></li>';
		echo '<li><a href="' . df_getfeedURL('summary') . '">Summary Feed</a></li>';
		echo '<li><a href="' . get_bloginfo('comments_rss2_url') . '">Comments Feed</a></li></ul>';
	}
}
// ***************************************************************************************

// ****** FUNCTION TO ADD ADMIN PAGE TO PRESENTATION MENU ******
function dualfeeds_admin() {
	if (function_exists('add_options_page')) {
		add_options_page('DualFeeds Setup', 'DualFeeds', 10, basename(__FILE__), 'dualfeeds_admin_page');
	}
}
// ************************************************************

// ****** FUNCTION TO DRAW OPTIONS PAGE CONTENT ******
function dualfeeds_admin_page(){
	// declare globals so we have access to them
	global $dualfeeds_options;
	// Post the form
	if (isset($_POST['dualfeeds_options_submit'])) {
		if ($_POST['df_switchdefault']=='true') {$dualfeeds_options['df_switch'] = 'true';} else {$dualfeeds_options['df_switch'] = 'false';} 
		$dualfeeds_options['df_summarylength'] = trim($_POST['df_maxlength']);
		$dualfeeds_options['df_sidebarimage'] = trim($_POST['df_sidebarimage']);
		if ($_POST['df_sidebarshowtext']=='true') {$dualfeeds_options['df_sidebarshowtext'] = 'true';} else {$dualfeeds_options['df_sidebarshowtext'] = 'false';}
		$dualfeeds_options['df_ifyoulikedthis'] = trim($_POST['df_ifyoulikedthis']);
		$dualfeeds_options['df_ifyoulikedthissize'] = trim($_POST['df_ifyoulikedthissize']);
		if ($_POST['df_showposts']=='true') {$dualfeeds_options['df_showposts'] = 'true';} else {$dualfeeds_options['df_showposts'] = 'false';}
		if ($_POST['df_showpages']=='true') {$dualfeeds_options['df_showpages'] = 'true';} else {$dualfeeds_options['df_showpages'] = 'false';}
		if ($_POST['df_showhome']=='true') {$dualfeeds_options['df_showhome'] = 'true';} else {$dualfeeds_options['df_showhome'] = 'false';}
		if ($_POST['df_showcategory']=='true') {$dualfeeds_options['df_showcategory'] = 'true';} else {$dualfeeds_options['df_showcategory'] = 'false';}
		if ($_POST['df_showdate']=='true') {$dualfeeds_options['df_showdate'] = 'true';} else {$dualfeeds_options['df_showdate'] = 'false';}
		if ($_POST['df_showtag']=='true') {$dualfeeds_options['df_showtag'] = 'true';} else {$dualfeeds_options['df_showtag'] = 'false';}
		if ($_POST['df_topborder']=='true') {$dualfeeds_options['df_topborder'] = 'true';} else {$dualfeeds_options['df_topborder'] = 'false';}
		if ($_POST['df_bottomborder']=='true') {$dualfeeds_options['df_bottomborder'] = 'true';} else {$dualfeeds_options['df_bottomborder'] = 'false';}
		$dualfeeds_options['df_autodiscovery1'] = $_POST['df_autodiscovery1'];
		$dualfeeds_options['df_autodiscovery2'] = $_POST['df_autodiscovery2'];
		$dualfeeds_options['df_autodiscoveryC'] = $_POST['df_autodiscoveryC'];
		$dualfeeds_options['df_feedburnerURL1'] = apply_filters('pre_comment_author_url', trim($_POST['df_feedburnerURL1']));
		$dualfeeds_options['df_feedburnerURL2'] = apply_filters('pre_comment_author_url', trim($_POST['df_feedburnerURL2']));
		$dualfeeds_options['df_feedburnerURLcomments'] = apply_filters('pre_comment_author_url', trim($_POST['df_feedburnerURLcomments']));
		update_option('dualfeeds_options', $dualfeeds_options);
		echo '<div id="message" class="updated fade"><p><strong>';
		_e('Options saved.');
		echo '</strong></p></div>';
	} 

	// Warn them if they don't have Syndication Feeds (in Options -> Reading) set to Full Text
	$df_rss_use_excerpt = get_option(rss_use_excerpt);
	if ($df_rss_use_excerpt == 1) {
		echo '<div id="error" class="error fade"><p><strong>ERROR</strong>: You have the "<i>For each article, show</i>" field set to <b>Summary</b> in the Syndication Feeds section of the <a href="options-reading.php">Options -> Reading page</a>. You must change this to <b>Full text</b> for DualFeeds to work.</p></div>';
	}

	// now drop out of php to create the HTML for the Options page
?>
	<div class="wrap">
	<h2>DualFeeds Information</h2>

	<script language = "javascript">	
		// function to send ajax call to get version from server 
		function df_servercall() {
			// Generate the request object 
			if (window.XMLHttpRequest) { 	// Mozilla & other compliant browsers
				df_request = new XMLHttpRequest();
			} else if (window.ActiveXObject) { 	// Internet Explorer
				df_request = new ActiveXObject("Microsoft.XMLHTTP");
			}
			// If we couldn't create a request object, error out.
			if (!df_request) {
				alert('Browser does not support AJAX!');
				return false;
			}
			// Open the connection, set where response will go and send request.
			df_request.open('GET', '<?php echo DF_PATH; ?>/versioncheck.php?appname=dualfeeds&version=<?php echo DF_VERSION; ?>', true);
			var df_version = document.getElementById("df_version");
			df_request.onreadystatechange = function() {
				if (df_request.readyState == 4 && df_request.status == 200) {
					df_version.innerHTML = df_request.responseText;
				}
			}
			df_request.send(null);
		}
	  </script>
	
	<!-- Show Version information, create span to put ajax call return and create Check for Update button -->
	<strong>Version:</strong><?php echo DF_VERSION . ' (' . DF_DATE . ')'; ?> 
	<span id="df_version">
	<noscript><span style="background:#444444; padding:2px; color:#FFFFFF"><strong>Javascript must be enabled to check for updates</strong></span></noscript>
	</span> 
	<div class="submit" style="text-align: left"><input type="button" id="df_update" name="df_update" onClick="df_servercall()" value="<?php _e('Check For Update &raquo;') ?>" /></div>
	
	<!-- Show the Feed URLs for this site -->
	<p><strong>Feed URLs For Your Site:</strong><ul><li>First Feed: <?php echo get_bloginfo('rss2_url'); ?></li> 
	<li>Second Feed: <?php echo df_addURLparam('dualfeed=2'); ?></li></ul></p>
	</div>

	<div class="wrap">
	<h2>DualFeeds Settings</h2>
	<!-- Start Form (Posts to this page) -->
	<form name="dualfeeds_options_form" action="<?php echo $_SERVER['PHP_SELF'] . '?page=' . basename(__FILE__); ?>" method="post">
	<!-- Show Top Update Button -->
	<div class="submit" style="float:right">
	<input type="submit" name="dualfeeds_options_submit" value="<?php _e('Update Options &raquo;') ?>"/>
	</div>	
	
	<!-- The General Settings section of the option page -->
	<h3>General Settings</h3>
	<ul>
	<li><strong>Switch Default Behaviour</strong>: <input type="checkbox" name="df_switchdefault" id="df_switch" value="true" <?php if ($dualfeeds_options['df_switch']=='true') {echo 'checked="checked"';}?> /><br />
	Check this to make first feed = summary and second feed = full post.
	</li>
	<li><strong>Maximum Summary Length</strong>: <input type="text" size="5" name="df_maxlength" id="df_maxlength" value="<?php echo $dualfeeds_options['df_summarylength'];?>" /><br />
	The maximum length of the summary (if there is no excerpt and no &lt;!--more--&gt; tag). Entries will be truncated after the last full word.
	</li>
	<li><strong>Create Feed AutoDiscovery Links</strong>: <input type="checkbox" name="df_autodiscovery1" id="df_autodiscovery1" value="true" <?php if ($dualfeeds_options['df_autodiscovery1']=='true') {echo 'checked="checked"';}?> />First Feed
	<input type="checkbox" name="df_autodiscovery2" id="df_autodiscovery2" value="true" <?php if ($dualfeeds_options['df_autodiscovery2']=='true') {echo 'checked="checked"';}?> />Second Feed
	<input type="checkbox" name="df_autodiscoveryC" id="df_autodiscoveryC" value="true" <?php if ($dualfeeds_options['df_autodiscoveryC']=='true') {echo 'checked="checked"';}?> />Comment Feed
	<br />Note: If your Theme already includes autodiscovery links for the main and/or comment feeds, checking the corresponding box above will create duplicates. See <a href="http://www.scratch99.com/2007/11/feed-autodiscovery-links/">this article</a> for more information on feed autodiscovery.
	</li>
	</ul>
	
	<!-- The FeedBurner Settings section of the option page -->
	<h3>FeedBurner Settings</h3>
	<p>If you do not use FeedBurner, leave these fields empty.</p>
	<p>If you use FeedBurner, DualFeeds can redirect feed requests to your FeedBurner URLs. Plugins such as FeedBurner's FeedSmith do this BUT DON'T WORK for the second feed. See <a href="http://www.scratch99.com/wordpress-plugin-dualfeeds/using-dualfeeds-with-feedburner/">this article</a> for more information on using DualFeeds with FeedBurner.</p>
	<ul>
	<li><strong>FeedBurner URL For First Feed</strong>: <input type="text" size="70" name="df_feedburnerURL1" id="df_feedburnerURL1" value="<?php echo $dualfeeds_options['df_feedburnerURL1'];?>" /><br />
	(note: leave this blank if you want an existing plugin, such as FeedSmith, to do this).
	</li>
	<li>
	<strong>FeedBurner URL For Second Feed</strong>: <input type="text" size="70" name="df_feedburnerURL2" id="df_feedburnerURL2" value="<?php echo $dualfeeds_options['df_feedburnerURL2'];?>" /><br />
	(note: plugins such as FeedSmith cannot do this for you).
	</li>
	<li><strong>FeedBurner URL For Comments</strong>: <input type="text" size="70" name="df_feedburnerURLcomments" id="df_feedburnerURLcomments" value="<?php echo $dualfeeds_options['df_feedburnerURLcomments'];?>" /><br />
	(note: leave this blank if you want an existing plugin, such as FeedSmith, to do this).
	</li>
	</ul>
	
	<!-- The Sidebar Settings section of the option page -->
	<h3>Sidebar Settings</h3>
	<p>Usage: Either enable the DualFeeds Sidebar Widget in Presentation -> Widgets or call dualfeeds_sidebar() in sidebar.php.</p>
	<ul>
	<li><strong>Sidebar Image (shown at half-size)</strong>
<?php 
	// use php to dynamically create the image selection part of the form
	$df_images = array('black', 'orangemix', 'orangewhite', 'orangeblack', 'orangemix-g', 'orangewhite-g', 'orangeblack-g', 'blue', 'green', 'purple', 'colourful', 'kubrick', 'white');
	foreach ($df_images as $value){
		echo '<div style="width:120px; margin:6px; float:left">'."\n";
		echo '<img src="'. DF_PATH . '/images/' . $value . '.png" height="41" width="92"/><BR />'."\n".'<input type="radio" name="df_sidebarimage" value="' . $value . '.png" ';
		if ($dualfeeds_options['df_sidebarimage']==$value.'.png') {echo 'checked="checked" ';}
		echo '/>' . $value . '</div>'."\n";
	};
?>
	<div style="clear:both"></div>
	</li>
	<li><strong>Show Text Instead Of Image</strong>: <input type="checkbox" name="df_sidebarshowtext" id="df_sidebarshowtext" value="true" <?php if ($dualfeeds_options['df_sidebarshowtext']=='true') {echo 'checked="checked"';}?> /><br /> 
	Uses your default sidebar style to list the feeds (may not work well with some themes).
	</li>
	</ul>

	<!-- The Post Settings section of the option page -->
	<h3>Post Settings</h3>
	<p>DualFeeds can add a link to the Full Post, Summary and Comments feeds at the bottom of each post.</p>
	<ul>
	<li><strong>Text At Bottom Of Post</strong><br />
	<input type="text" size="70" name="df_ifyoulikedthis" id="df_ifyoulikedthis" value="<?php echo $dualfeeds_options['df_ifyoulikedthis'];?>" />
	</li>
	<li><strong>Size of Icon</strong>
	<div style="width:150px; margin-top:6px; float:left; ">
	<input type="radio" name="df_ifyoulikedthissize" value="feed-icon16.gif" <?php if ($dualfeeds_options['df_ifyoulikedthissize']=='feed-icon16.gif') {echo 'checked="checked" ';} ?> />16px
	<img src="<?php echo DF_PATH; ?>/images/feed-icon16.gif" height="16" width="16" style="vertical-align:top" /></div>
	<div style="width:150px; margin-top:6px; float:left; ">
	<input type="radio" name="df_ifyoulikedthissize" value="feed-icon24.gif" <?php if ($dualfeeds_options['df_ifyoulikedthissize']=='feed-icon24.gif') {echo 'checked="checked" ';} ?> />24px
	<img src="<?php echo DF_PATH; ?>/images/feed-icon24.gif" height="24" width="24" style="vertical-align:top" /></div>
	<div style="width:150px; margin-top:6px; float:left; ">
	<input type="radio" name="df_ifyoulikedthissize" value="feed-icon32.gif" <?php if ($dualfeeds_options['df_ifyoulikedthissize']=='feed-icon32.gif') {echo 'checked="checked" ';} ?> />32px
	<img src="<?php echo DF_PATH; ?>/images/feed-icon32.gif" height="32" width="32" style="vertical-align:top" /></div>
	<div style="clear:both"></div>
	</li>	
	<li><strong>Border</strong>
	<div style="width:150px; float:left"><input type="checkbox" name="df_topborder" id="df_topborder" value="true" <?php if ($dualfeeds_options['df_topborder']=='true') {echo 'checked="checked"';}?> /> Top Border</div>
	<div style="width:150px; float:left"><input type="checkbox" name="df_bottomborder" id="df_bottomborder" value="true" <?php if ($dualfeeds_options['df_bottomborder']=='true') {echo 'checked="checked"';}?> /> Bottom Border</div>
	<div style="clear:both"></div>
	</li>
	<li><strong>Where Should It Appear</strong>
	<div style="width:450px"><div style="width:150px; float:left"><input type="checkbox" name="df_showposts" id="df_showposts" value="true" <?php if ($dualfeeds_options['df_showposts']=='true') {echo 'checked="checked"';}?> /> Individual Posts</div>
	<div style="width:150px; float:left"><input type="checkbox" name="df_showpages" id="df_showpages" value="true" <?php if ($dualfeeds_options['df_showpages']=='true') {echo 'checked="checked"';}?> /> Individual Pages</div>
	<div style="width:150px; float:left"><input type="checkbox" name="df_showhome" id="df_showhome" value="true" <?php if ($dualfeeds_options['df_showhome']=='true') {echo 'checked="checked"';}?> /> Home Page</div></div>
	<div style="width:450px"><div style="width:150px; float:left"><input type="checkbox" name="df_showcategory" id="df_showcategory" value="true" <?php if ($dualfeeds_options['df_showcategory']=='true') {echo 'checked="checked"';}?> /> Category Archives</div>
	<div style="width:150px; float:left"><input type="checkbox" name="df_showtag" id="df_showtag" value="true" <?php if ($dualfeeds_options['df_showtag']=='true') {echo 'checked="checked"';}?> /> Tag Archives (2.3)</div>
	<div style="width:150px; float:left"><input type="checkbox" name="df_showdate" id="df_showdate" value="true" <?php if ($dualfeeds_options['df_showdate']=='true') {echo 'checked="checked"';}?> /> Date Archives</div></div>
	</li>
	</ul>
	
	<!-- Show Bottom Update Button -->
	<div class="submit" style="float:right">
	<input type="submit" name="dualfeeds_options_submit" value="<?php _e('Update Options &raquo;') ?>"/>
	</div>
	<!-- End Form -->
	</form>
	<div style="clear:both"></div>
	</div>
	
	<!-- Thank You Section -->
	<div class="wrap">
	<p>Thank you for using the DualFeeds plugin. If you like it, please link to the <a href="http://www.scratch99.com/wordpress-plugin-dualfeeds/">DualFeed home page</a> so others can find out about it and/or make a donation via the home page.</p>
	<div style="font-size:0.9em">DualFeeds Copyright 2007 by Stephen Cronin. Released under the GNU General Public License (version 2 or later).</div>
	</div>
	
<?php
}
// *********** END  DUALFEEDS_ADMIN_PAGE  FUNCTION ***********

// ****** FUNCTION TO REDIRECT FEED REQUESTS TO FEEDBURNER ******
function df_feedburner_redirect(){
	// only do anything if it is a feed and if the user agent isn't feedburner or a feedvalidator
	if (!preg_match("/feedburner|feedvalidator/i", $_SERVER['HTTP_USER_AGENT']) && is_feed()) {

		// declare globals so we have access to them
		global $dualfeeds_options, $wp, $feed, $withcomments;
		
		// if it's not comments or archive (date, category, tag) then it is a post feed
		if ($feed != 'comments-rss2' && $withcomments != 1 && !is_archive()) {
		
			// if it is the second feed and there is a FeedBurner URL for second feed
			if (strpos($_SERVER['REQUEST_URI'],'dualfeed=2') && trim($dualfeeds_options['df_feedburnerURL2']) != '') {
				if (function_exists('status_header')) {status_header( 307 );}
				header("Location:" . trim($dualfeeds_options['df_feedburnerURL2']));
				header("HTTP/1.1 307 Temporary Redirect");
				die;
			}
			// if it is NOT the second feed and there is a FeedBurner URL for first feed
			if (!strpos($_SERVER['REQUEST_URI'],'dualfeed=2') && trim($dualfeeds_options['df_feedburnerURL1']) != '') {
				if (function_exists('status_header')) {status_header( 307 );}
				header("Location:" . trim($dualfeeds_options['df_feedburnerURL1']));
				header("HTTP/1.1 307 Temporary Redirect");
				die;
			}
		}
		// if it's comments and if there is anything in the parameter  
		if (($feed == 'comments-rss2' || $withcomments == 1) && trim($dualfeeds_options['df_feedburnerURLcomments']) != '') {
			if (function_exists('status_header')) {status_header( 307 );}
			header("Location:" . trim($dualfeeds_options['df_feedburnerURLcomments']));
			header("HTTP/1.1 307 Temporary Redirect");
			die;		
		}		
	}
}
// *************************************************************

// ****** FUNCTION TO REDIRECT FEED REQUESTS TO FEEDBURNER IF FILE ACCESSED DIRECTLY ******
function df_check_url() {
	global $dualfeeds_options;
	$df_thisfile = basename($_SERVER['PHP_SELF']);
	// if it is one of the feed files
	if ($df_thisfile == 'wp-rss.php' || $df_thisfile == 'wp-rss2.php' || $df_thisfile == 'wp-atom.php' || $df_thisfile == 'wp-rdf.php') {
		// redirect: if it is the second feed and there is something in the FeedBurner URL for Second Feed field.
		if (strpos($_SERVER['REQUEST_URI'],'dualfeed=2') && trim($dualfeeds_options['df_feedburnerURL2']) != '') {
			if (function_exists('status_header')) status_header( 307 );
			header("Location:" . trim($dualfeeds_options['df_feedburnerURL2']));
			header("HTTP/1.1 307 Temporary Redirect");
			die;
		}
		// redirect: if it's not the second feed and there is something in the FeedBurner URL for First Feed field.
		if (!strpos($_SERVER['REQUEST_URI'],'dualfeed=2') && trim($dualfeeds_options['df_feedburnerURL1']) != '') {
			if (function_exists('status_header')) status_header( 307 );
			header("Location:" . trim($dualfeeds_options['df_feedburnerURL1']));
			header("HTTP/1.1 307 Temporary Redirect");
			die;
		}
	}
	// redirect: if it's the comments feed and if there is something in the FeedBurner URL for Comments Feed field
	if ($df_thisfile == 'wp-commentsrss2.php') {
		if (trim($dualfeeds_options['df_feedburnerURLcomments']) != '') {
			if (function_exists('status_header')) status_header( 307 );
			header("Location:" . trim($dualfeeds_options['feedburner_comments_url']));
			header("HTTP/1.1 307 Temporary Redirect");
			die;
		}
	}
}
// *************************************************************

// ****** FUNCTION TO RETURN THE APPROPRIATE FEED URL FOR THIS SITE ******
function df_getfeedURL($df_feed) {
	global $dualfeeds_options;
	if ( ($df_feed == 'summary' && $dualfeeds_options['df_switch']!='true') ||
	($df_feed != 'summary' && $dualfeeds_options['df_switch']=='true') ) {
		return df_addURLparam('dualfeed=2');
	}
	else {
		return get_bloginfo('rss2_url');
	}
}
// ********************************************************************

// ****** FUNCTION TO ADD DUALFEED=2 TO URL TAKING PERMALINKS INTO ACCOUNT ******
function df_addURLparam($df_param) {
	if (! stristr(get_bloginfo('rss2_url'),'?')) {
		return get_bloginfo('rss2_url') . '?'. $df_param;
	}
	else {
		return get_bloginfo('rss2_url') . '&' . $df_param;
	}
}
// *****************************************************************************

// ****** FUNCTION TO RETURN THE APPROPRIATE DESCRIPTION FOR THIS FEED ******
function df_getdescription($df_feedno) {
	global $dualfeeds_options;
	if ( ($df_feedno == 'dualfeed=2' && $dualfeeds_options['df_switch']!='true') ||
	($df_feedno != 'dualfeed=2' && $dualfeeds_options['df_switch']=='true') ) {		
		return 'Summary Feed';
	}
	else {
		return 'Full Post Feed';
	}
}
// ************************************************************************
?>