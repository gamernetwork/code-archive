======================================
Plugin Name: DualFeeds
Plugin URI: http://www.scratch99.com/wordpress-plugin-dualfeeds/
Description: Allows you to offer your readers both a full post feed and a summary feed. Works for all post feeds (main site feed, category feeds, etc). Comment feeds are unaffected.
Version: 1.11
Date: 28th December 2007
Author: Stephen Cronin
Author URI: http://www.scratch99.com/
======================================

======================================
**** RELEASE NOTES ****
These notes belong to this release of the Dual Feeds plugin for WordPress. 
For up to date information see http://www.scratch99.com/wordpress-plugin-dualfeeds/

INTRODUCTION
DualFeeds turns your feed into two separate feeds (full post and summary), allowing your readers to subscribe the feed of their choice.

FEATURES
- Allows you to offer readers both a full post feed and a summary feed 
- Works for all feeds (category, tag, author, etc) not just main site feed 
- Sidebar widget with links to Full Post, Summary and Comments feeds 
- Optional links to Full Post, Summary & Comments feeds after each post 
- Feed requests for each of the three feeds can be redirected to the appropriate FeedBurner URL (use it with or instead of FeedSmith) 
- Option to turn on feed autodiscovery links for each of the three feeds 

WHY USE IT?
Some of your subscribers prefer having the full post to read now, others prefer summaries they can skim through now and follow up later. Without DualFeeds you must choose which format to offer them. 
DualFeeds lets you offer both formats, so YOUR SUBSCRIBERS CAN MAKE THEIR OWN CHOICE.

HOW IT WORKS
DualFeeds catches all feed requests (except comments) and formats the output: By default it strips the <!�more�> tag giving the full post. If it finds dualfeed=2 in the URL, it creates a summary as follows (in order of precedence, first to last):
	- The extract is used, if one exists. 
	- The post is cut at the <!�more�> tag, if it exists. 
	- The post is cut after a user-definable number of characters. 

DOES IT WORK WITH FEEDBURNER?
Yes! And DualFeeds 1.1 and above can redirect feed requests for the Full Post, Summary and Comments feeds to the appropriate FeedBurner URL. Use DualFeeds to redirect the second feed only and leave the rest to FeedSmith (or similar plugin), or get DualFeeds to redirect all three. 
See the Using DualFeeds With FeedBurner article (http://www.scratch99.com/wordpress-plugin-dualfeeds/using-dualfeeds-with-feedburner/) for more information on using DualFeeds with FeedBurner.

REQUIREMENTS
	- Should work on WordPress 2.x.x. Tested on WordPress 2.3, 2.2.2 and 2.1.3.
	- The �Full text� option must be selected in Options -> Reading.

INSTALLATION
	- Download the dualfeeds.zip file and unzip it. 
	- Upload the dualfeeds folder to your site�s wp-content/plugins folder. 
	- Activate the plugin within WordPress. 

UPGRADE
	- Download the dualfeeds.zip file and unzip it. 
	- Upload the dualfeeds folder to your site�s wp-content/plugins folder, overwriting the existing files. 
	- De-activate the plugin within WordPress, then activate it again immediately (to apply defaults)

OPTIONS
See the DualFeeds Options Guide (http://www.scratch99.com/wordpress-plugin-dualfeeds/dualfeeds-options-guide/) for detailed information on Options.

USAGE
The first feed is accessed through your normal feed URL. The �second feed� is accessed by adding dualfeed=2 to the URL, eg: 
	- http://www.yoursite.com/feed/?dualfeed=2 (if using permalinks) 
	- http://www.yoursite.com/?feed=rss2&dualfeed=2 (no permalinks) 
There�s no need to guess - the first and second feed URLs for your main site feed are shown in the DualFeeds Options page.
The usage of dualfeed=2 applies to all feeds (eg category feeds, etc). For information on using other feeds, see this article by Lorelle VanFossen:
http://lorelle.wordpress.com/2007/01/24/understanding-using-and-customizing-wordpress-blog-feeds/ 

AUTOMATICALLY ADDING A LINK TO THE �SECOND FEED�
DualFeeds includes a sidebar widget, which prominently displays links to the Full Post, Summary and Comments feeds. This can be added through the Presentation -> Widgets screen, or can be called by adding <?php  dualfeeds_sidebar(); ?> to sidebar.php in your theme folder. 
For information on the widget�s options, see the DualFeeds Options Guide (http://www.scratch99.com/wordpress-plugin-dualfeeds/dualfeeds-options-guide/). 
Advanced users will probably want to set the link up manually, to tie in with their existing link / theme.

MANUALLY ADDING A LINK TO THE �SECOND FEED�
You can manually add a link to the �second feed� underneath the existing link to the normal feed. 
You will need to find where the existing link is set up, copy and paste the code for the existing link, then add the dualfeed=2 parameter to the second link. You should also change the descriptions to indicate which feed is which.
Where this needs to be done depends on where your existing feed link is setup. If it is in the sidebar, you will need to edit one of the following: 
	- sidebar.php in your theme folder (if you don�t use widgets) 
	- widgets.php in the wp-includes folder (if you use widgets in 2.2+) 
	- wp-content/plugins/widgets/widgets.php (if you use widgets pre 2.2) 
You could use just enter the appropriate URL from the DualFeeds Option page, but it is better to let WordPress work out the URL (in case you change your permalink structure later). For example:
<li><a href="<?php bloginfo('rss2_url'); ?>?dualfeed=2" title="<?php _e('Syndicate this site using RSS'); ?>"><?php _e('<abbr title="Really Simple Syndication">Entries RSS (Summary)</abbr>'); ?></a></li>
Important: If you don�t use permalinks, use &dualfeed=2 in place of ?dualfeed=2 above.

COMPATIBILITY
DualFeeds works with FeedBurner�s FeedSmith plugin and Flagrant Disregard�s Feedburner Plugin, although it includes most of their functionality and can replace them.
The Full Text Feed plugin may strip the <!�more�> tag before DualFeeds gets the content, meaning DualFeeds cannot use the more tag to create the summary. Most of Full Text Feed�s features are included in DualFeeds.
DualFeeds has not been extensively tested with other feed plugins but I do not envisage problems. If you do encounter problems, please let me know.

RELATED PLUGINS
If you simply want to offer a full post feed, rather than BOTH a full post feed AND a summary feed, then I recommend the Full Text Feed plugin.

TROUBLESHOOTING
If viewing the feed in a web browser, you may not see changes to the settings work until you clear your browser cache (Tools->Clear Private Data in Firefox, Tools->Internet Options->Delete Files in Internet Explorer).
Most modern web browsers only show summaries when viewing feeds, even if the full post is actually in the feed. Right-click on the page and choose View Source to verify whether the feed contains the full post or not.

SUPPORT
This plugin is officially not supported (due to my time constraints), but if you leave a comment on the plugin's home page or contact me, I should be able to help.

PASSWORD PROTECTED POSTS
Wordpress does not include the content of Password protected posts in feeds, but there are some reports of a bug where the content does appear. This plugin ensures that it does not appear.

ACKNOWLEDGEMENTS
This plugin was inspired by the discussion in the comments of RT Cunningham�s Should There Be Advertisements In Blog Feeds? (http://www.untwistedvortex.com/2007/08/04/should-there-be-advertisements-in-blog-feeds/#comment-10558).
The sidebar widget & feed links after each post were inspired by Glen Allsop�s Increase Your RSS Subscribers with Simple Tweaks (no longer available).
To provide software, you need people willing to bravely step in and test beta versions. Thanks to Dmitry (http://www.sportreport.ru/) for helping me track down an obscure bug in v1.0.

DISCLAIMER:
This plugin is released under the GPL licence (http://www.gnu.org/copyleft/gpl.html). I do not accept any responsibility for any damages or losses, direct or indirect, that may arise from using the plugin or these instructions. This software is provided as is, with absolutely no warranty. Please refer to the full version of the GPL license for more information.
