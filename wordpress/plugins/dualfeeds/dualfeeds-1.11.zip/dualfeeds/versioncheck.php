<?php
/*
Receives AJAX calls from plugin, requests lastest version from http://www.scratch99.com/, then returns latest version to plugin. 
Necessary, because cross domain ajax calls cannot be made by the plugin.

version: 1.1
date: 8th November 2007

   Copyright 2007  Stephen Cronin  (email : sjc@scratch99.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// get parameters passed with URL
$scratch_appused = ($_GET['appname']);
$scratch_versionused = ($_GET['version']);

// set host name variable
$scratch_host = 'http://www.scratch99.com/versioncheck.php?appname=' . $scratch_appused . '&version=' . $scratch_versionused;

// grab the contents of the file
$data = @file_get_contents($scratch_host);

// Define that we are returning XML content & not to cache it
header('Content-Type: text/xml');
header('Cache-control: no-cache');

// if we couldn't get anything from the server
if ($data === false) {
        echo '<span style="background:#444444; padding:2px; color:#FFFFFF"><strong>Unable to connect to the server. Please try again later</strong></span>';
        return false;
}

// return the data from the server
echo $data;

?>