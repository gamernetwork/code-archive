# AMP 301

**AMP 301** is a simple plugin that applies the functionality of <a href="https://en-gb.wordpress.org/plugins/simple-301-redirects/">Simple 301 Redirects</a> to AMP (<a href="https://www.ampproject.org/">Accelerated Mobile Pages</a>) articles.

## Required plugins:

+ <a href="https://en-gb.wordpress.org/plugins/simple-301-redirects/">Simple 301 Redirects</a>
+ <a href="https://wordpress.org/plugins/amp/">AMP</a>

## TODO:

This plugin does not currently support the **wildcard** functionality of **Simple 301 Redirects**.