<?php
/*
Plugin Name: Simple Comment Editing
Plugin URI: http://wordpress.org/extend/plugins/simple-comment-editing/
Description: Simple comment editing for your users.
Author: Ronald Huereca
Version: 2.1.5
Requires at least: 4.1
Author URI: http://www.ronalfy.com
Contributors: ronalfy
Text Domain: simple-comment-editing
Domain Path: /languages
*/ 
require( 'simple-comment-editing.php' );