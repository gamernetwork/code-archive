<?php
/**
 * Plugin Name: JAS Admin Post Time
 * Plugin URI: 
 * Description: Add time to the date / time column for future posts.
 * Version: 1.0
 * Author: Jonathan Sutcliffe
 * License: GPL2
 */
 
 // Add time to the date / time column for future posts
function jas_post_date_column_time( $h_time, $post ) {
// If post is scheduled then add the time to the column output
if ($post->post_status == 'future') {
$h_time .= '<br>' . get_post_time( 'g:i a', false, $post );
}
// Return the column output
return $h_time;
}
add_filter ( 'post_date_column_time' , 'jas_post_date_column_time' , 10 , 2 );
?>