<?php
namespace W3TC;

/**
 * W3 CDN MaxCDN Class
 */
class CdnEngine_Mirror_MaxCdn extends CdnEngine_Mirror_Netdna {}
