<?php
$servers = \WP_Defender\Behavior\Utils::instance()->serverTypes();

if ( DIRECTORY_SEPARATOR == '\\' ) {
	//Windows
	$wp_includes = str_replace( ABSPATH, '', WPINC );
	$wp_content  = str_replace( ABSPATH, '', WP_CONTENT_DIR );
} else {
	$wp_includes = str_replace( $_SERVER['DOCUMENT_ROOT'], '', ABSPATH . WPINC );
	$wp_content  = str_replace( $_SERVER['DOCUMENT_ROOT'], '', WP_CONTENT_DIR );
}
global $is_nginx, $is_IIS, $is_iis7;
$setting = \WP_Defender\Module\Hardener\Model\Settings::instance();
if ( $is_nginx ) {
	$setting->active_server = 'nginx';
} else if ( $is_IIS ) {
	$setting->active_server = 'iis';
} else if ( $is_iis7 ) {
	$setting->active_server = 'iis-7';
}
$checked = $controller->check();
?>
<div id="prevent-php-execute" class="sui-accordion-item <?php echo $controller->getCssClass() ?>">
    <div class="sui-accordion-item-header">
        <div class="sui-accordion-item-title">
            <i aria-hidden="true" class="<?php echo $checked ? 'sui-icon-check-tick sui-success'
				: 'sui-icon-warning-alert sui-warning' ?>"></i>
			<?php _e( "PHP Execution", "defender-security" ) ?>
        </div>
        <div class="sui-accordion-col-4">
            <button class="sui-button-icon sui-accordion-open-indicator" aria-label="Open item">
                <i class="sui-icon-chevron-down" aria-hidden="true"></i>
            </button>
        </div>
    </div>
    <div class="sui-accordion-item-body">
        <div class="sui-box">
            <div class="sui-box-body">
                <strong><?php _e( "Overview", "defender-security" ) ?></strong>
                <p>
					<?php
					_e( "By default, a plugin/theme vulnerability could allow a PHP file to get uploaded into your site's directories and in turn execute harmful scripts that can wreak havoc on your website. Prevent this altogether by disabling direct PHP execution in directories that don't require it.", "defender-security" )
					?>
                </p>
                <strong>
					<?php _e( "Status", "defender-security" ) ?>
                </strong>
				<?php if ( $checked ): ?>
                    <div class="sui-notice sui-notice-success">
                        <p>
		                    <?php _e( "You've automatically disabled PHP execution..", "defender-security" ) ?>
                        </p>
                    </div>
				<?php else: ?>
                    <div class="sui-notice sui-notice-warning">
                        <p>
							<?php _e( "PHP execution is currently allowed in all directories.", "defender-security" ) ?>
                        </p>
                    </div>
                    <p>
						<?php _e( "Currently, all directories can have PHP code executed in them. It’s best to lock this down to only the directories that require, and add any further execeptions you need.", "defender-security" ) ?>
                    </p>
                    <strong>
						<?php _e( "How to fix", "defender-security" ) ?>
                    </strong>
                    <p>
						<?php _e( "We can lock down directories WordPress doesn’t need to protect you from PHP execution attacks. You can also add exceptions for specific files you need to run. Alternately, you can ignore this tweak if you don’t require it. Either way, you can easily revert these actions at any time.", "defender-security" ) ?>
                    </p>
                    <div class="sui-tabs sui-side-tabs">
                        <div data-tabs>
                            <div class="<?php echo $setting->active_server == 'apache' ? 'active' : '' ?>"><?php _e( "Apache", "defender-security" ) ?></div>
                            <div class="<?php echo $setting->active_server == 'litespeed' ? 'active' : '' ?>"><?php _e( "Litespeed", "defender-security" ) ?></div>
                            <div class="<?php echo $setting->active_server == 'nginx' ? 'active' : '' ?>"><?php _e( "Nginx", "defender-security" ) ?></div>
                            <div class="<?php echo $setting->active_server == 'iis' ? 'active' : '' ?>"><?php _e( "IIS", "defender-security" ) ?></div>
                            <div class="<?php echo $setting->active_server == 'iis7' ? 'active' : '' ?>"><?php _e( "IIS7", "defender-security" ) ?></div>
                        </div>

                        <div data-panes>
                            <div class="sui-tab-boxed <?php echo $setting->active_server == 'apache' ? 'active' : '' ?>">
								<?php $controller->renderPartial( 'rules/prevent-php/apache_litespeed', array(
									'setting' => $setting
								) ) ?>
                            </div>
                            <div class="sui-tab-boxed <?php echo $setting->active_server == 'litespeed' ? 'active' : '' ?>">
								<?php $controller->renderPartial( 'rules/prevent-php/apache_litespeed', array(
									'setting' => $setting
								) ) ?>
                            </div>
                            <div class="sui-tab-boxed hardener-instructions <?php echo $setting->active_server == 'nginx' ? 'active' : '' ?>">
								<?php $controller->renderPartial( 'rules/prevent-php/nginx', array(
									'setting' => $setting
								) ) ?>
                            </div>
                            <div class="sui-tab-boxed <?php echo $setting->active_server == 'iis' ? 'active' : '' ?>">
                                <p><?php printf( __( 'For IIS servers, <a href="%s">visit Microsoft TechNet</a>', "defender-security" ), 'https://technet.microsoft.com/en-us/library/cc725855(v=ws.10).aspx' ); ?></p>
                            </div>
                            <div class="sui-tab-boxed <?php echo $setting->active_server == 'iis7' ? 'active' : '' ?>">
								<?php $controller->renderPartial( 'rules/prevent-php/iis7', array(
									'setting' => $setting
								) ) ?>
                            </div>

                        </div>

                    </div>
				<?php endif; ?>
            </div>
            <div class="sui-box-footer">
                <div class="sui-actions-left">
					<?php $controller->showIgnoreForm() ?>
                </div>
            </div>
        </div>
    </div>
</div>