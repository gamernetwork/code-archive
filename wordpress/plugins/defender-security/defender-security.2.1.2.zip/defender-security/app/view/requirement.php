<div class="wrap">
	<div class="wp-defender">
		<div class="wdf-requirement">
			<h2 class="title">

			</h2>
		</div>
	</div>
	<dialog id="requirement">
		<div class="line">
			<?php _e( "Defender is currently scanning your files for malicious code, please be patient this should on take a
            few minutes depending on the size of your website.", "defender-security" ) ?>
		</div>

	</dialog>
</div>