# WP Edmonds (Magnet Affiliates Integration)

The Magnet Affiliates plugin adds support for Edmonds affiliate blocks on WordPress
sites.

## Installation

To install, clone the repo into the `wp-content/plugins` directory and enable via
the admin panel.

As long as the plugin is enabled, this should work out of the box with no further development,
although it will probably require some extra styling.

## Configration

+ `EDMONDS_SCRIPT_URL` - **required** - The URL for the Edmonds client script, e.g. `//cdn.gamer-network.net/2017/scripts/edmonds/1.0.1/edmonds.js`
+ `EDMONDS_SERVICE_URL` - **optional** - The URL for Edmonds Service. This should only be set when developing. If not set, the client script will be responsible for determining where to connect to.

**Note:** When connecting to the service, the `site` variable will be set by pulling the domain from the `WP_SITEURL` setting.
If the domain does not exist as a site in the service, no products will be returned. If working on a dev version, you will
need to ensure that a site and tracking ID are set for that domain.

## Usage

To use, add an `[affiliates]` shortcode anywhere in an article. The attributes are passed as options to
the client script. A list of which options are available can be seen in <a href="https://docs.google.com/a/eurogamer.biz/document/d/1xTm9_wvLMEs6GnGBB6MgAlIUyd778Avgjz5AqT2nQCY/edit?usp=sharing">general usage documentation</a>.

An affiliates tag should look something like this:

```
[affiliates campaign="pokemon" department="clothing"]
```

## Related libraries

+ <a href="https://github.com/gamernetwork/edmonds-client">Edmonds client script</a>
+ <a href="https://github.com/gamernetwork/edmonds-service">Edmonds service</a>
+ <a href="https://github.com/gamernetwork/edmonds">Edmonds core and admin</a>
