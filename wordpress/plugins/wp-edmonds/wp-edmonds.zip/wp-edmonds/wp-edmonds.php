<?php

/**
 * Plugin Name: Magnet Affiliates Integration
 * Description: Tool for embedding Magnet affiliate blocks into articles
 * Version: 1.0.0
 * Author: Thomas Marchant
 */


include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

/**
 * Convert `[affiliates]` tag to a div with attributes used as data attributes
 */
function parse_affiliates_tag($args) {
  array_walk($args, function (&$value) {
    $value = htmlentities($value);
  });
  ob_start();
  ?>
    <div class="edmonds-block" <?php foreach ($args as $key => $value) :?>data-<?php echo $key; ?>='<?php echo $value; ?>' <?php endforeach; ?>></div>
  <?php
  $tag = ob_get_contents();
  ob_end_clean();

  return $tag;
}

/**
 * Apply `edmonds_affiliate_tag()` to `[affiliates]` tag
 */
function register_affiliates_tag($postID) {
  add_shortcode('affiliates', 'parse_affiliates_tag');
}

/**
 * Inject Edmonds client script to hook up to API.
 * Note: This script requires jQuery. WordPress does have a means of adding dependencies
 * for JavaScript using the 'enqueued scripts' feature. However, we cannot use this
 * as we do not have a guarantee that jQuery will be registered using this feature (as
 * opposed to hardcoded with a script tag). Instead, this is called in the footer, where
 * jQuery should already been included.
 */
function inject_edmonds_script() {
  $src = "//cdn.gamer-network.net/2018/scripts/edmonds/1.3.1/edmonds.js";
  if (defined('EDMONDS_SCRIPT_URL')) {
    $src = EDMONDS_SCRIPT_URL;
  }

  ?><script src="<?php echo $src; ?>"></script><?php
}

/**
 * Inject script to parse attributes on affiliates blocks to send to the client script
 */
function get_affiliate_products() {
  // Get the domain name from the configured site URL
  preg_match('/^https?\:\/\/(?:www.)?([a-zA-Z0-9\-_\.]+)?/', WP_SITEURL, $matches);
  $site = $matches[1];

  // Output script to make call to client script (and therefore API)
  ?>

    <script>
      jQuery(document).ready(function() {
          renderEdmonds('.edmonds-block', {
              'site': '<?php echo $site; ?>',
              <?php if (defined('EDMONDS_SERVICE_URL')) : ?>'edmonds_url': '<?php echo EDMONDS_SERVICE_URL; ?>',<?php endif; ?>

          });
      });
    </script>
  <?php
}

add_action('init', 'register_affiliates_tag');
add_action('wp_footer', 'inject_edmonds_script');
add_action('wp_footer', 'get_affiliate_products');
